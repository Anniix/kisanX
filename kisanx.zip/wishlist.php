<?php
session_start();
include 'php/language_init.php';
include 'php/db.php';

// Redirect if not logged in
if(empty($_SESSION['user'])){ header('Location: login.php'); exit; }

// Handle Remove Action
if(isset($_POST['action']) && $_POST['action'] == 'remove'){
    $pid = (int)$_POST['product_id'];
    unset($_SESSION['wishlist'][$pid]);
    $_SESSION['popup_message'] = $lang['toast_wishlist_remove'] ?? "Removed from wishlist";
    header("Location: wishlist.php"); exit;
}

// Fetch Wishlist Products
$wishlist_ids = isset($_SESSION['wishlist']) ? array_keys($_SESSION['wishlist']) : [];
$products = [];
if(!empty($wishlist_ids)){
    $placeholders = implode(',', array_fill(0, count($wishlist_ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($wishlist_ids);
    $products = $stmt->fetchAll();
}
?>
<!doctype html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>My Wishlist — KisanX</title>
    
    <script>
    (function() {
        try {
            const theme = localStorage.getItem('theme');
            if (theme === 'light') { document.documentElement.classList.add('light-mode'); }
        } catch (e) {}
    })();
    </script>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            /* Dark Mode Variables (Default) - Matching Screenshot */
            --bg-body: #0d1117;
            --bg-card: #161b22;
            --border-color: #30363d;
            --accent-green: #4ade80;
            --accent-hover: #22c55e;
            --text-main: #ffffff;
            --text-muted: #8b949e;
            --shadow: 0 4px 20px rgba(0,0,0,0.4);
        }

        /* Light Mode Overrides */
        html.light-mode {
            --bg-body: #f3f4f6;       /* Light Gray Background */
            --bg-card: #ffffff;       /* White Cards */
            --border-color: #e5e7eb;  /* Light Gray Border */
            --accent-green: #10b981;  /* Slightly darker green for light mode contrast */
            --accent-hover: #059669;
            --text-main: #111827;     /* Dark Charcoal Text */
            --text-muted: #6b7280;    /* Gray Text */
            --shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
            flex: 1;
        }

        /* --- Header Section --- */
        .page-header {
            text-align: center;
            margin-bottom: 60px;
            margin-top: 20px;
        }

        .page-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
        }

        .highlight-green {
            color: var(--accent-green);
        }

        /* --- Empty State Container --- */
        .empty-container {
            background-color: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 80px 20px;
            text-align: center;
            max-width: 800px;
            margin: 0 auto;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
        }

        .empty-container h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--text-main);
        }

        .empty-container p {
            color: var(--text-muted);
            font-size: 1rem;
            margin-bottom: 40px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.5;
        }

        .btn-browse {
            background-color: var(--accent-green);
            color: #000000; /* Always black text on green button for legibility */
            padding: 14px 32px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .btn-browse:hover {
            background-color: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(74, 222, 128, 0.3);
        }

        /* --- Product Grid --- */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 25px;
        }

        .card {
            background-color: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            position: relative;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow);
        }

        .card:hover {
            transform: translateY(-5px);
            border-color: var(--accent-green);
        }

        .card img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            /* In light mode, we don't want a black background behind images if they load slowly */
            background-color: var(--border-color); 
        }

        .card-content {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .card h4 {
            margin: 0 0 10px 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-main);
        }

        .price {
            color: var(--accent-green);
            font-weight: 700;
            font-size: 1.2rem;
            margin-bottom: 15px;
        }

        .remove-btn {
            margin-top: auto;
            background: transparent;
            border: 1px solid #ef4444;
            color: #ef4444;
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: 0.3s;
        }

        .remove-btn:hover {
            background: #ef4444;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <main class="container">
        
        <div class="page-header">
            <h1><span class="highlight-green">My</span> Wishlist</h1>
        </div>
        
        <?php if(empty($products)): ?>
            <div class="empty-container">
                <h2>Your wishlist is currently empty.</h2>
                <p>Browse products and click the "♡ Add to Wishlist" button to save your favorites here.</p>
                <a href="user_dashboard.php" class="btn-browse">Browse Products</a>
            </div>
        <?php else: ?>
            <div class="grid">
                <?php foreach($products as $p): ?>
                    <div class="card">
                        <img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
                        <div class="card-content">
                            <h4><?php echo htmlspecialchars($p['name']); ?></h4>
                            <div class="price">₹<?php echo number_format($p['price'], 2); ?></div>
                            
                            <form method="POST">
                                <input type="hidden" name="action" value="remove">
                                <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                                <button type="submit" class="remove-btn">Remove Item</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </main>
    <?php include 'footer.php'; ?>
</body>
</html>