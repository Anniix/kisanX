<?php
session_start();
include 'php/language_init.php';
include 'php/db.php';

if(empty($_SESSION['user']) || $_SESSION['user']['role']!='customer'){ header('Location: login.php'); exit; }
$user_id = $_SESSION['user']['id'];

/* --- BACKEND LOGIC --- */
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(isset($_POST['wishlist_action'])){
        $pid = (int)($_POST['product_id'] ?? 0);
        if($pid){
            if(!isset($_SESSION['wishlist'])) $_SESSION['wishlist'] = [];
            if($_POST['wishlist_action']==='add') { $_SESSION['wishlist'][$pid]=time(); $_SESSION['popup_message'] = $lang['toast_wishlist_add']; }
            if($_POST['wishlist_action']==='remove') { unset($_SESSION['wishlist'][$pid]); $_SESSION['popup_message'] = $lang['toast_wishlist_remove']; }
        }
    }
    if(isset($_POST['cart_action']) && $_POST['cart_action'] === 'add'){
        $product_id = (int)($_POST['product_id'] ?? 0);
        $qty = (int)($_POST['qty'] ?? 1);
        if($product_id > 0 && $qty > 0){
            $stmt = $pdo->prepare("SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$user_id, $product_id]);
            $existing_item = $stmt->fetch();
            if($existing_item){
                $new_qty = $existing_item['qty'] + $qty;
                $updateStmt = $pdo->prepare("UPDATE cart_items SET qty = ? WHERE user_id = ? AND product_id = ?");
                $updateStmt->execute([$new_qty, $user_id, $product_id]);
                $_SESSION['popup_message'] = $lang['toast_cart_update'];
            } else {
                $insertStmt = $pdo->prepare("INSERT INTO cart_items (user_id, product_id, qty) VALUES (?, ?, ?)");
                $insertStmt->execute([$user_id, $product_id, $qty]);
                $_SESSION['popup_message'] = $lang['toast_cart_add'];
            }
        }
    }
    if(isset($_POST['cart_action']) && $_POST['cart_action'] === 'remove'){
        $pid = (int)($_POST['product_id'] ?? 0);
        if($pid){ $stmt = $pdo->prepare("DELETE FROM cart_items WHERE user_id=? AND product_id=?"); $stmt->execute([$user_id, $pid]); }
    }
    header('Location: user_dashboard.php'); exit;
}

$popup_message = '';
if(isset($_SESSION['popup_message'])){ $popup_message = $_SESSION['popup_message']; unset($_SESSION['popup_message']); }

// SEARCH LOGIC
$search = trim($_GET['q'] ?? '');
$category_filter = (int)($_GET['category'] ?? 0);
$params = []; $where = ' WHERE 1=1 ';
if($search){ $where .= ' AND (p.name LIKE ? OR p.description LIKE ?) '; $params[]="%$search%"; $params[]="%$search%"; }
if($category_filter){ $where .= ' AND p.category_id = ? '; $params[] = $category_filter; }

$sql = "SELECT p.*, c.name as category FROM products p LEFT JOIN categories c ON p.category_id=c.id $where ORDER BY p.created_at DESC LIMIT 60";
$stmt = $pdo->prepare($sql); $stmt->execute($params); $products = $stmt->fetchAll();

$bestStmt = $pdo->query("SELECT p.*, c.name as category, COALESCE(SUM(oi.qty),0) as total_sold FROM products p LEFT JOIN categories c ON p.category_id = c.id LEFT JOIN order_items oi ON p.id = oi.product_id GROUP BY p.id ORDER BY total_sold DESC LIMIT 8");
$bestSellers = $bestStmt->fetchAll();

$cats = $pdo->query('SELECT * FROM categories')->fetchAll();

$ordersStmt = $pdo->prepare('SELECT o.*, COALESCE(SUM(oi.qty),0) as items FROM orders o LEFT JOIN order_items oi ON o.id=oi.order_id WHERE o.user_id=? GROUP BY o.id ORDER BY o.created_at DESC');
$ordersStmt->execute([$user_id]); $orders = $ordersStmt->fetchAll();
?>
<!doctype html>
<html lang="<?php echo $current_lang; ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title><?php echo $lang['user_dashboard_title']; ?></title>
<script>
(function() {
    try {
        const theme = localStorage.getItem('theme');
        if (theme === 'light') { document.documentElement.classList.add('light-mode'); }
    } catch (e) {}
})();
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
    :root {
        --sidebar-width: 260px;
        --kd-bg: #12181b;
        --kd-bg-surface: #1a2226;
        --kd-earthy-green: #68d391;
        --kd-warm-gold: #f5b041;
        --kd-text: #e6f1ff;
        --kd-muted: #a0aec0;
        --kd-danger: #e53e3e;
        --glass-bg: rgba(26, 34, 38, 0.7);
        --glass-border: rgba(160, 174, 192, 0.15);
        --card-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
        --info-blue: #3182ce;
        --radius: 16px;
    }
    
    html.light-mode {
        --kd-bg: #F3F4F6;
        --kd-bg-surface: #FFFFFF;
        --kd-earthy-green: #059669;
        --kd-warm-gold: #D97706;
        --kd-text: #111827;
        --kd-muted: #6B7280;
        --kd-danger: #DC2626;
        --glass-bg: rgba(255, 255, 255, 0.9);
        --glass-border: rgba(0, 0, 0, 0.08);
        --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }

    @keyframes fadeInUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
    @keyframes pulse-glow { 0% { box-shadow: 0 0 0 0 rgba(104, 211, 145, 0.7); } 70% { box-shadow: 0 0 0 15px rgba(104, 211, 145, 0); } 100% { box-shadow: 0 0 0 0 rgba(104, 211, 145, 0); } }
    @keyframes message-pop-in { from { opacity: 0; transform: translateY(10px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
    @keyframes ripple { to { transform: scale(4); opacity: 0; } }
    @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    *, *::before, *::after { box-sizing: border-box; }
    body { margin: 0; font-family: 'Poppins', sans-serif; background: var(--kd-bg); color: var(--kd-text); -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; overflow-x: hidden; min-height: 100vh; padding-top: 0; }
    body.sidebar-open { overflow: hidden; }

    .page-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(4px); z-index: 1040; opacity: 0; transition: opacity 0.3s ease; }
    body.sidebar-open .page-overlay { display: block; opacity: 1; }
    
    /* Mobile Header Bar (Visible only on mobile/tablet) */
    .mobile-top-bar { display: none; }

    /* Hamburger */
    .hamburger { display: flex; position: fixed; top: 20px; left: 20px; z-index: 1200; width: 32px; height: 26px; flex-direction: column; justify-content: space-between; cursor: pointer; transition: left 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); padding: 5px; background: rgba(0,0,0,0.2); border-radius: 4px; backdrop-filter: blur(4px); }
    .hamburger span { display: block; height: 3px; width: 100%; background: var(--kd-text); border-radius: 4px; transition: transform 0.3s ease, opacity 0.3s ease; }
    body.sidebar-open .hamburger { left: calc(var(--sidebar-width) + 20px); background: transparent; }
    body.sidebar-open .hamburger span:nth-child(1) { transform: translateY(11px) rotate(45deg); }
    body.sidebar-open .hamburger span:nth-child(2) { opacity: 0; }
    body.sidebar-open .hamburger span:nth-child(3) { transform: translateY(-11px) rotate(-45deg); }

    /* Sidebar */
    .sidebar { position: fixed; top: 0; left: 0; width: var(--sidebar-width); height: 100vh; background: var(--kd-bg-surface); border-right: 1px solid var(--glass-border); padding-top: 80px; transform: translateX(-100%); transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1); z-index: 1050; box-shadow: var(--card-shadow); display: flex; flex-direction: column; }
    body.sidebar-open .sidebar { transform: translateX(0); }
    .sidebar a { display: flex; align-items: center; gap: 15px; padding: 1rem 1.5rem; color: var(--kd-muted); font-weight: 500; text-decoration: none; transition: all 0.2s ease; border-left: 4px solid transparent; font-size: 1rem; }
    .sidebar a:hover, .sidebar a.active { background: rgba(104, 211, 145, 0.08); color: var(--kd-text); border-left-color: var(--kd-earthy-green); }
    html.light-mode .sidebar a:hover { background: rgba(5, 150, 105, 0.08); }
    
    header.sticky-header { position: sticky; top: 0; z-index: 1000; transition: transform 0.3s ease; background: var(--glass-bg); backdrop-filter: blur(10px); border-bottom: 1px solid var(--glass-border); }
    header.sticky-header.header-hidden { transform: translateY(-100%); }
    header .logo { padding-left: 60px; height: 70px; display: flex; align-items: center; }

    main.container { padding: 2rem 2%; max-width: 1600px; margin: 0 auto; padding-top: 40px; }

    /* Titles - CENTERED */
    h2.welcome-title { font-family: 'Montserrat', sans-serif; font-size: clamp(1.8rem, 5vw, 3rem); font-weight: 800; margin-bottom: 2rem; text-align: center; display: flex; justify-content: center; gap: 0.3em; flex-wrap: wrap; letter-spacing: -1px; }
    .welcome-title .h-word { display: inline-block; opacity: 0; transform: translateY(30px) rotateZ(3deg); transition: transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.8s ease; }
    .welcome-title.is-visible .h-word { opacity: 1; transform: translateY(0) rotateZ(0); }
    .welcome-title.is-visible .h-word:nth-child(2) { transition-delay: 0.1s; color: var(--kd-earthy-green); }

    /* CENTERED SECTION TITLES */
    .section-title { 
        font-family: 'Montserrat', sans-serif; 
        font-size: clamp(1.4rem, 4vw, 2.2rem); 
        font-weight: 700; 
        text-align: center; /* Center Text */
        margin: 3rem auto 1.5rem; 
        color: var(--kd-text); 
        padding-bottom: 10px; 
        display: block;
        width: 100%;
    }
    .section-title span { color: var(--kd-earthy-green); }

    .scroll-trigger { opacity: 0; transform: translateY(30px); transition: opacity 0.6s ease-out, transform 0.6s ease-out; }
    .scroll-trigger.is-visible { opacity: 1; transform: translateY(0); }
    
    /* Search Box - CENTERED */
    .search-box {
        display: flex; flex-wrap: wrap; gap: 0.8rem; padding: 1rem;
        background: var(--kd-bg-surface); border: 1px solid var(--glass-border); border-radius: var(--radius);
        margin: 0 auto 2rem auto; /* Center Container */
        max-width: 800px; /* Limit Width */
        transition: all 0.3s ease;
        position: relative; box-shadow: var(--card-shadow);
        justify-content: center; /* Center items inside */
    }
    .search-box:focus-within { border-color: var(--kd-earthy-green); transform: translateY(-2px); }
    .search-input {
        flex: 1; padding: 1rem 1.2rem; border-radius: 8px;
        border: 1px solid var(--glass-border); background: var(--kd-bg); color: var(--kd-text);
        font-size: 1rem; transition: all .3s ease; min-width: 200px;
    }
    html.light-mode .search-input { background: #F9FAFB; }
    .search-input:focus { outline: none; border-color: var(--kd-earthy-green); }
    
    .category-modal-trigger { display: flex; justify-content: space-between; align-items: center; padding: 0 1.2rem; border-radius: 8px; border: 1px solid var(--glass-border); background: var(--kd-bg); color: var(--kd-text); font-size: 0.95rem; cursor: pointer; transition: all .3s ease; min-width: 180px; height: 50px; }
    html.light-mode .category-modal-trigger { background: #F9FAFB; }
    .category-modal-trigger:hover { background: rgba(104, 211, 145, 0.1); border-color: var(--kd-earthy-green); }
    .category-modal-trigger .arrow { width: 8px; height: 8px; border-right: 2px solid var(--kd-muted); border-bottom: 2px solid var(--kd-muted); transform: rotate(45deg); margin-top: -4px; transition: transform 0.3s; }
    .hidden-select { display: none; }

    .ripple-btn { position: relative; overflow: hidden; }
    span.ripple { position: absolute; border-radius: 50%; transform: scale(0); animation: ripple 600ms linear; background-color: rgba(255, 255, 255, 0.4); }

    .search-btn { background: var(--kd-earthy-green); color: #fff; border: none; padding: 0 2rem; height: 50px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: all .3s ease; font-size: 1rem; }
    .search-btn:hover { background: #55b880; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(104, 211, 145, 0.4); }
    
    /* Grids & Cards */
    .grid { 
        display: grid; 
        gap: 1.5rem; 
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); 
        width: 100%;
    }
    
    .card {
        background: var(--kd-bg-surface); border: 1px solid var(--glass-border);
        border-radius: var(--radius); overflow: hidden;
        box-shadow: var(--card-shadow); transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        display: flex; flex-direction: column; height: 100%; position: relative;
    }
    .card.stagger-in { animation: fadeInUp 0.6s cubic-bezier(0.2, 0.8, 0.2, 1) both; }
    .card:hover {
        transform: translateY(-8px); 
        border-color: var(--kd-earthy-green);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2), 0 0 0 1px rgba(104, 211, 145, 0.2);
        z-index: 2;
    }
    
    .card img { width: 100%; height: 200px; object-fit: cover; transition: transform 0.6s ease; background: var(--kd-bg); }
    .card:hover img { transform: scale(1.08); }
    
    .card-content { padding: 1.25rem; flex-grow: 1; display: flex; flex-direction: column; gap: 0.5rem; }
    .card h4 { margin: 0; font-size: 1.1rem; color: var(--kd-text); font-weight: 600; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .card p { margin: 0; color: var(--kd-muted); font-size: 0.9rem; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; height: 2.7em; }
    .price { font-weight: 700; font-size: 1.2rem; color: var(--kd-warm-gold); margin-top: auto; }
    .card-actions { margin-top: 1rem; display: flex; flex-wrap: wrap; gap: 0.6rem; }
    
    .cart-btn, .wishlist-btn, .info-btn { 
        padding: 0.7rem; border: 1px solid; border-radius: 8px; 
        cursor: pointer; font-weight: 600; text-align: center; transition: all 0.2s ease; 
        position: relative; overflow: hidden; font-size: 0.9rem;
    }
    .cart-btn { width: 100%; background: var(--kd-earthy-green); color: #fff; border-color: var(--kd-earthy-green); margin-bottom: 0.5rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    .cart-btn:hover { background: #48bb78; border-color: #48bb78; transform: translateY(-1px); }
    
    .wishlist-form { flex: 4; }
    .wishlist-btn { width: 100%; background: transparent; color: var(--kd-muted); border-color: var(--glass-border); }
    .wishlist-btn:hover { border-color: var(--kd-warm-gold); color: var(--kd-warm-gold); }
    .wishlist-btn.active { background: rgba(229, 62, 62, 0.1); color: var(--kd-danger); border-color: var(--kd-danger); }
    
    .info-btn { flex: 1; background: transparent; color: var(--info-blue); border-color: var(--glass-border); font-size: 1.1rem; padding: 0.6rem; }
    .info-btn:hover { background: var(--info-blue); color: #fff; border-color: var(--info-blue); }
    
    .qty-selector { display: flex; align-items: center; justify-content: center; margin-bottom: 0.8rem; width: 100%;}
    .qty-selector button { width: 40px; height: 36px; font-size: 1.2rem; background: var(--kd-bg); color: var(--kd-muted); border: 1px solid var(--glass-border); cursor: pointer; transition: .2s; display: flex; align-items: center; justify-content: center; }
    .qty-selector button:first-child { border-radius: 6px 0 0 6px; }
    .qty-selector button:last-child { border-radius: 0 6px 6px 0; }
    .qty-selector button:hover { background: var(--kd-bg-surface); color: var(--kd-text); border-color: var(--kd-muted); }
    .qty-selector input { width: 100%; height: 36px; text-align: center; background: var(--kd-bg); border: none; border-top: 1px solid var(--glass-border); border-bottom: 1px solid var(--glass-border); color: var(--kd-text); font-size: 1rem; font-weight: 600; }

    /* Categories Horizontal Scroll on Mobile */
    .categories { margin-top: 3rem; overflow-x: hidden; }
    .category-grid { display: flex; justify-content: center; gap: 2.5rem; flex-wrap: wrap; padding: 1rem; }
    .category-item { display: flex; flex-direction: column; align-items: center; text-decoration: none; color: var(--kd-text); opacity: 0; transition: transform 0.3s ease; }
    .categories.is-visible .category-item { opacity: 1; transform: translateX(0); }
    .category-item:hover { transform: translateY(-8px); }
    .category-circle { width: 120px; height: 120px; border-radius: 50%; background: var(--kd-bg-surface); display: flex; justify-content: center; align-items: center; margin-bottom: 1rem; overflow: hidden; border: 3px solid var(--glass-border); box-shadow: var(--card-shadow); transition: border-color 0.3s ease; }
    .category-item:hover .category-circle { border-color: var(--kd-earthy-green); }
    .category-circle img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; }
    .category-item:hover .category-circle img { transform: scale(1.15); }
    .category-label { font-weight: 600; font-size: 1rem; letter-spacing: 0.5px; }

    /* Tables */
    .table-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; background: var(--kd-bg-surface); border: 1px solid var(--glass-border); border-radius: 12px; padding: 0; box-shadow: var(--card-shadow); }
    table { width: 100%; border-collapse: collapse; min-width: 600px; }
    table th, table td { padding: 1.2rem 1rem; text-align: left; font-size: 0.95rem; white-space: nowrap; }
    table th { background: rgba(104, 211, 145, 0.05); color: var(--kd-earthy-green); font-weight: 700; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px; border-bottom: 2px solid var(--glass-border); }
    table td { color: var(--kd-muted); border-bottom: 1px solid var(--glass-border); }
    table tbody tr:last-child td { border-bottom: none; }
    table tbody tr:hover { background: rgba(255,255,255,0.02); }
    html.light-mode table tbody tr:hover { background: rgba(0,0,0,0.02); }
    .track-btn { background: transparent; color: var(--kd-warm-gold); border: 1px solid var(--kd-warm-gold); padding: 0.4rem 1rem; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all .3s ease; display: inline-block; font-size: 0.85rem; }
    .track-btn:hover { background: var(--kd-warm-gold); color: #fff; }

    /* Modals */
    .modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; opacity: 0; animation: fadeIn 0.3s forwards; }
    @keyframes fadeIn { to { opacity: 1; } }
    .modal-content { padding: 2rem; width: 90%; max-width: 450px; text-align: center; background: var(--kd-bg-surface); border: 1px solid var(--glass-border); border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.6); position: relative; overflow: hidden; transform: scale(0.9); animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
    @keyframes popIn { to { transform: scale(1); } }
    .modal-content h4 { font-family: 'Montserrat',sans-serif; margin-top:0; color:var(--kd-text); font-size: 1.4rem; }
    .modal-content p { color:var(--kd-muted); line-height: 1.6; }
    .modal-content button { padding:.8rem 1.8rem; border-radius:8px; font-weight:600; border:none; cursor:pointer; margin: 1rem 0.5rem 0; transition:all .3s ease; font-size: 0.95rem; }
    .confirm-remove { background:var(--kd-danger); color:#fff; box-shadow: 0 4px 10px rgba(229, 62, 62, 0.3); }
    .confirm-remove:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(229, 62, 62, 0.4); }
    .cancel-remove { background:var(--glass-bg); color:var(--kd-text); border: 1px solid var(--glass-border); }
    .cancel-remove:hover { background: var(--glass-border); }
    .confirm-btn { background:var(--kd-earthy-green); color:#fff; box-shadow: 0 4px 10px rgba(104, 211, 145, 0.3); }
    .confirm-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(104, 211, 145, 0.4); }

    /* Comparison Modal Specifics */
    .comparison-table { margin: 1rem 0; }
    .comparison-table th { background: transparent; padding: 0.5rem; border-bottom: 1px solid var(--glass-border); color: var(--kd-text); font-size: 0.9rem; }
    .comparison-table td { padding: 0.8rem 0.5rem; border-bottom: 1px solid var(--glass-border); color: var(--kd-muted); font-size: 1rem; }
    .comparison-table .price-high { color: var(--kd-danger); font-weight: 600; }
    .comparison-table .price-low { color: var(--kd-earthy-green); font-weight: 800; font-size: 1.2rem; }
    .comparison-table .store-name { font-weight: 500; display: flex; align-items: center; gap: 8px; font-size: 0.95rem; }

    /* Category Modal List */
    .category-list { margin-top: 1.5rem; text-align: left; max-height: 50vh; overflow-y: auto; padding-right: 5px; }
    .category-option { display: block; padding: 1rem; border-radius: 8px; cursor: pointer; font-weight: 500; transition: all 0.2s ease; border-bottom: 1px solid var(--glass-border); }
    .category-option:hover { background-color: rgba(104, 211, 145, 0.1); color: var(--kd-earthy-green); padding-left: 1.5rem; }

    /* CHATBOT */
    .chat-widget-btn {
        position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px;
        background: var(--kd-earthy-green); color: white; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 8px 25px rgba(104, 211, 145, 0.5); cursor: pointer; z-index: 1600;
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: none; font-size: 28px;
        animation: pulse-glow 3s infinite;
    }
    .chat-widget-btn:hover { transform: scale(1.1) rotate(10deg); animation: none; }
    
    .chat-window {
        position: fixed; bottom: 100px; right: 30px; width: 360px; height: 500px;
        background: var(--kd-bg-surface); border: 1px solid var(--glass-border);
        border-radius: 20px; overflow: hidden; display: none; flex-direction: column;
        z-index: 1600; box-shadow: 0 20px 50px rgba(0,0,0,0.4);
        animation: slideUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
    }
    .chat-header { background: linear-gradient(135deg, var(--kd-earthy-green), #1A4D2E); padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; color: white; }
    .chat-header h5 { margin: 0; font-family: 'Montserrat', sans-serif; font-size: 1rem; letter-spacing: 0.5px; }
    .chat-close { background: none; border: none; color: white; font-size: 24px; cursor: pointer; padding: 0; line-height: 1; opacity: 0.8; }
    .chat-close:hover { opacity: 1; transform: scale(1.1); }
    .chat-body { flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; background: var(--kd-bg); }
    .chat-message { max-width: 85%; padding: 10px 14px; border-radius: 12px; font-size: 0.9rem; line-height: 1.5; white-space: pre-wrap; animation: message-pop-in 0.3s ease-out forwards; word-wrap: break-word; }
    .chat-bot { background: var(--kd-bg-surface); align-self: flex-start; border-bottom-left-radius: 2px; color: var(--kd-text); border: 1px solid var(--glass-border); box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .chat-user { background: var(--kd-earthy-green); color: white; align-self: flex-end; border-bottom-right-radius: 2px; box-shadow: 0 4px 10px rgba(104, 211, 145, 0.2); }
    .chat-footer { padding: 10px; border-top: 1px solid var(--glass-border); display: flex; gap: 8px; background: var(--kd-bg-surface); }
    .chat-input { flex: 1; padding: 10px 15px; border-radius: 20px; border: 1px solid var(--glass-border); background: var(--kd-bg); color: var(--kd-text); outline: none; transition: all 0.2s; font-size: 0.9rem; }
    .chat-input:focus { border-color: var(--kd-earthy-green); }
    .chat-send { background: var(--kd-earthy-green); border: none; width: 40px; height: 40px; border-radius: 50%; color: white; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: transform 0.2s; }
    .chat-send:hover { transform: scale(1.1); }
    .chat-chip-container { padding: 0 15px 15px; display: flex; flex-wrap: wrap; gap: 6px; background: var(--kd-bg); }
    .chat-chip { background: var(--kd-bg-surface); border: 1px solid var(--glass-border); color: var(--kd-muted); padding: 6px 12px; border-radius: 12px; font-size: 0.75rem; cursor: pointer; transition: all 0.2s; user-select: none; }
    .chat-chip:hover { border-color: var(--kd-earthy-green); color: var(--kd-earthy-green); background: rgba(104, 211, 145, 0.05); }

    /* --- RESPONSIVE MEDIA QUERIES --- */
    
    /* Tablet (max-width: 1024px) */
    @media (max-width: 1024px) {
        main.container { padding: 3rem 3%; padding-top: 80px; }
        .grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); }
        .category-grid { gap: 1.5rem; }
        
        /* Show Mobile Header Bar on Tablet too */
        .mobile-top-bar { 
            display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 60px; 
            background: var(--kd-bg-surface); border-bottom: 1px solid var(--glass-border);
            z-index: 1100; align-items: center; justify-content: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1); backdrop-filter: blur(10px);
        }
        .mobile-logo { font-family: 'Montserrat', sans-serif; font-weight: 800; font-size: 1.4rem; color: var(--kd-earthy-green); }
        .hamburger { top: 17px; background: transparent; backdrop-filter: none; }
    }

    /* Mobile (max-width: 768px) */
    @media (max-width: 768px) {
        :root { --sidebar-width: 280px; }
        
        body.sidebar-open .hamburger { left: calc(var(--sidebar-width) + 10px); }
        
        main.container { padding: 2rem 1rem; padding-top: 80px; max-width: 100%; }
        header .logo { display: none; } 
        
        /* Two Column Grid for Mobile - Like Apps */
        .grid { 
            grid-template-columns: repeat(2, 1fr); 
            gap: 10px; 
        }
        
        .card { border-radius: 12px; }
        .card img { height: 140px; }
        .card-content { padding: 0.8rem; }
        .card h4 { font-size: 0.95rem; line-height: 1.3; }
        .card p { font-size: 0.8rem; display: none; }
        .price { font-size: 1rem; margin-top: 0.5rem; }
        
        .qty-selector { margin-bottom: 0.5rem; }
        .qty-selector button { width: 30px; height: 30px; font-size: 1rem; }
        .qty-selector input { height: 30px; font-size: 0.9rem; }
        
        .card-actions { gap: 0.4rem; }
        .cart-btn { padding: 0.6rem; font-size: 0.85rem; margin-bottom: 0.4rem; }
        .wishlist-btn, .info-btn { padding: 0.5rem; }
        
        /* Horizontal Scroll for Categories on Mobile */
        .category-grid { 
            justify-content: flex-start; /* Left align for scroll */
            flex-wrap: nowrap; 
            overflow-x: auto; 
            padding-bottom: 1rem; 
            gap: 1.5rem; 
            -webkit-overflow-scrolling: touch;
        }
        .category-item { flex: 0 0 auto; width: 80px; }
        .category-circle { width: 70px; height: 70px; margin-bottom: 0.5rem; border-width: 2px; }
        .category-label { font-size: 0.8rem; text-align: center; }
        
        /* Search Box Mobile */
        .search-box { flex-direction: column; padding: 0.8rem; gap: 0.8rem; margin: 0 0 2rem 0; width: 100%; }
        .search-input { width: 100%; }
        .category-modal-trigger { width: 100%; height: 45px; }
        .search-btn { width: 100%; height: 45px; }
        
        /* Chat Window Mobile */
        .chat-widget-btn { bottom: 20px; right: 20px; width: 55px; height: 55px; }
        .chat-window { 
            width: 92%; left: 4%; right: 4%; 
            bottom: 90px; height: 60vh; 
            border-radius: 16px; 
        }
        
        h2.welcome-title { font-size: 1.8rem; margin-top: 0; }
        .section-title { font-size: 1.4rem; margin: 2rem 0 1rem; }
        
        /* Modal Mobile */
        .modal-content { width: 95%; padding: 1.5rem; }
    }
    
    /* Small Mobile (max-width: 380px) */
    @media (max-width: 380px) {
        .grid { grid-template-columns: 1fr; } 
        .card img { height: 180px; }
        .card p { display: block; }
    }
</style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="mobile-top-bar">
    <div class="mobile-logo">KisanX</div>
</div>

<div class="page-overlay"></div>
<div class="hamburger"><span></span><span></span><span></span></div>
<div class="sidebar">
    <div style="padding: 0 1.5rem 1rem; color: var(--kd-earthy-green); font-weight: 800; font-size: 1.5rem; font-family: 'Montserrat', sans-serif;">KisanX</div>
    <a href="user_dashboard.php">🏠 <?php echo $lang['sidebar_dashboard']; ?></a>
    <a href="wishlist.php">💖 <?php echo $lang['sidebar_wishlist']; ?></a>
    <a href="cart.php">🛒 <?php echo $lang['sidebar_cart']; ?></a>
    <a href="orders.php">📦 <?php echo $lang['sidebar_orders']; ?></a>
    <a href="#" id="theme-toggle">🌓 <?php echo $lang['sidebar_theme'] ?? 'Switch Theme'; ?></a>
</div>

<main class="container">
    <h2 class="welcome-title scroll-trigger">
        <span class="h-word"><?php echo $lang['user_dashboard_welcome']; ?></span>
        <span class="h-word"><?php echo htmlspecialchars($_SESSION['user']['name']); ?></span>
    </h2>

    <div id="search-section" class="scroll-trigger">
        <h3 class="section-title"><span><?php echo $lang['user_dashboard_search_title_span']; ?></span> <?php echo $lang['user_dashboard_search_title']; ?></h3>
        <form method="get" class="search-box">
            <input type="text" name="q" class="search-input" placeholder="<?php echo $lang['user_dashboard_search_placeholder']; ?>" value="<?php echo htmlspecialchars($search); ?>">
            <div class="category-modal-trigger">
                <span><?php echo $lang['user_dashboard_all_categories']; ?></span>
                <div class="arrow"></div>
            </div>
            <select name="category" class="hidden-select">
                <option value=""><?php echo $lang['user_dashboard_all_categories']; ?></option>
                <?php foreach($cats as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php if($category_filter==$c['id']) echo 'selected'; ?>><?php echo htmlspecialchars($c['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="search-btn ripple-btn"><?php echo $lang['user_dashboard_search_button']; ?></button>
        </form>
    </div>
    
    <section class="categories scroll-trigger">
        <h3 class="section-title"><span><?php echo $lang['user_dashboard_shop_by_title_span']; ?></span> <?php echo $lang['user_dashboard_shop_by_title']; ?></h3>
        <div class="category-grid">
            <a href="products.php?category=vegetables" class="category-item"><div class="category-circle"><img src="vegetables.jpg" alt="Vegetables"></div><div class="category-label"><?php echo $lang['user_dashboard_category_veg']; ?></div></a>
            <a href="products.php?category=fruits" class="category-item"><div class="category-circle"><img src="fruits.jpg" alt="Fruits"></div><div class="category-label"><?php echo $lang['user_dashboard_category_fruits']; ?></div></a>
            <a href="products.php?category=grains" class="category-item"><div class="category-circle"><img src="grains.jpg" alt="Grains"></div><div class="category-label"><?php echo $lang['user_dashboard_category_grains']; ?></div></a>
            <a href="products.php?category=spices" class="category-item"><div class="category-circle"><img src="spices.jpg" alt="Spices"></div><div class="category-label"><?php echo $lang['user_dashboard_category_spices']; ?></div></a>
        </div>
    </section>

    <div id="products-section" class="products-list scroll-trigger">
        <h3 class="section-title"><span><?php echo $lang['user_dashboard_available_title_span']; ?></span> <?php echo $lang['user_dashboard_available_title']; ?></h3>
        <div class="grid">
            <?php foreach($products as $p): $inWishlist = isset($_SESSION['wishlist'][$p['id']]); $finalPrice = $p['price']*(1-$p['discount_percent']/100); ?>
                <div class="card stagger-in">
                    <?php if($p['image']): ?><img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>"><?php endif; ?>
                    <div class="card-content">
                        <div>
                            <h4><?php echo htmlspecialchars($p['name']); ?></h4>
                            <p><?php echo htmlspecialchars($p['description']); ?></p>
                            <p class="price">₹<?php echo number_format($finalPrice,2); ?></p>
                        </div>
                        <div class="card-actions">
                            <form method="post" action="user_dashboard.php" style="width:100%"><input type="hidden" name="product_id" value="<?php echo $p['id']; ?>"><input type="hidden" name="cart_action" value="add"><div class="qty-selector"><button type="button" class="minus-btn ripple-btn">-</button><input type="text" name="qty" value="1" min="1" readonly><button type="button" class="plus-btn ripple-btn">+</button></div><button type="submit" class="cart-btn ripple-btn"><?php echo $lang['card_add_to_cart']; ?></button></form>
                            <form method="post" action="" class="wishlist-form"><input type="hidden" name="product_id" value="<?php echo $p['id']; ?>"><input type="hidden" name="wishlist_action" value="<?php echo $inWishlist ? 'remove' : 'add'; ?>"><button type="submit" class="wishlist-btn ripple-btn <?php if($inWishlist) echo 'active'; ?>"><?php echo $inWishlist ? $lang['card_in_wishlist'] : $lang['card_add_wishlist']; ?></button></form>
                            <button type="button" class="info-btn ripple-btn compare-trigger" 
                                data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                                data-price="<?php echo $finalPrice; ?>">ℹ️</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="bestsellers-section" class="bestsellers-list scroll-trigger">
        <h3 class="section-title"><span><?php echo $lang['user_dashboard_bestsellers_title_span']; ?></span> <?php echo $lang['user_dashboard_bestsellers_title']; ?></h3>
        <div class="grid">
            <?php foreach($bestSellers as $index => $p): $inWishlist = isset($_SESSION['wishlist'][$p['id']]); $finalPrice = $p['price']*(1-$p['discount_percent']/100); ?>
                <div class="card stagger-in">
                    <?php if($p['image']): ?><img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>"><?php endif; ?>
                    <div class="card-content">
                        <div>
                            <h4><?php echo htmlspecialchars($p['name']); ?></h4>
                            <p><?php echo htmlspecialchars($p['description']); ?></p>
                            <p class="price">₹<?php echo number_format($finalPrice,2); ?></p>
                        </div>
                        <div class="card-actions">
                            <form method="post" action="user_dashboard.php" style="width:100%"><input type="hidden" name="product_id" value="<?php echo $p['id']; ?>"><input type="hidden" name="cart_action" value="add"><div class="qty-selector"><button type="button" class="minus-btn ripple-btn">-</button><input type="text" name="qty" value="1" min="1" readonly><button type="button" class="plus-btn ripple-btn">+</button></div><button type="submit" class="cart-btn ripple-btn"><?php echo $lang['card_add_to_cart']; ?></button></form>
                            <form method="post" action="" class="wishlist-form"><input type="hidden" name="product_id" value="<?php echo $p['id']; ?>"><input type="hidden" name="wishlist_action" value="<?php echo $inWishlist ? 'remove' : 'add'; ?>"><button type="submit" class="wishlist-btn ripple-btn <?php if($inWishlist) echo 'active'; ?>"><?php echo $inWishlist ? $lang['card_in_wishlist'] : $lang['card_add_wishlist']; ?></button></form>
                             <button type="button" class="info-btn ripple-btn compare-trigger" 
                                data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                                data-price="<?php echo $finalPrice; ?>">ℹ️</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="orders-section" class="scroll-trigger">
        <h3 class="section-title"><span><?php echo $lang['user_dashboard_orders_title_span']; ?></span> <?php echo $lang['user_dashboard_orders_title']; ?></h3>
        <?php if(!$orders): ?><p style="text-align:center; color: var(--kd-muted);"><?php echo $lang['user_dashboard_no_orders']; ?></p>
        <?php else: ?>
        <div class="table-wrapper">
            <table>
                <thead><tr>
                    <th><?php echo $lang['user_dashboard_order_table_id']; ?></th>
                    <th><?php echo $lang['user_dashboard_order_table_items']; ?></th>
                    <th><?php echo $lang['user_dashboard_order_table_total']; ?></th>
                    <th><?php echo $lang['user_dashboard_order_table_status']; ?></th>
                    <th><?php echo $lang['user_dashboard_order_table_date']; ?></th>
                    <th><?php echo $lang['user_dashboard_order_table_track']; ?></th>
                </tr></thead>
                <tbody>
                    <?php foreach($orders as $o): ?>
                        <tr>
                            <td>#<?php echo $o['id']; ?></td>
                            <td><?php echo $o['items']; ?></td>
                            <td><?php echo number_format($o['total_amount'] ?? $o['total'] ?? 0, 2); ?></td>
                            <td><?php echo htmlspecialchars(ucfirst($o['status'])); ?></td>
                            <td><?php echo date("d M, Y", strtotime($o['created_at'])); ?></td>
                            <td><a href="track.php?order_id=<?php echo $o['id']; ?>" class="track-btn ripple-btn"><?php echo $lang['user_dashboard_track_button']; ?></a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</main>

<div class="modal" id="comparisonModal">
    <div class="modal-content">
        <h4>Price Comparison 🔍</h4>
        <p>Market rates updated today!</p>
        <h5 id="compProductName" style="margin: 10px 0; color: var(--kd-text);"></h5>
        <div class="table-wrapper" style="box-shadow: none; border: none; background: transparent;">
            <table class="comparison-table" style="min-width: 100%;">
                <thead>
                    <tr>
                        <th>Platform</th>
                        <th>Price (est.)</th>
                    </tr>
                </thead>
                <tbody id="comparisonTableBody">
                </tbody>
            </table>
        </div>
        <button class="confirm-btn ripple-btn" onclick="closeComparisonModal()">Got it!</button>
    </div>
</div>

<div class="modal" id="removeModal">
    <div class="modal-content">
        <h4><?php echo $lang['user_dashboard_modal_remove_title']; ?></h4>
        <p><?php echo $lang['user_dashboard_modal_remove_p']; ?></p>
        <form method="post" id="confirmRemoveForm">
            <input type="hidden" name="product_id" id="removeProductId">
            <input type="hidden" name="wishlist_action" value="remove">
            <button type="button" class="cancel-remove ripple-btn" onclick="closeRemoveModal()"><?php echo $lang['user_dashboard_modal_cancel_button']; ?></button>
            <button type="submit" class="confirm-remove ripple-btn"><?php echo $lang['user_dashboard_modal_remove_button']; ?></button>
        </form>
    </div>
</div>

<div class="modal" id="successModal" style="<?php echo $popup_message ? 'display:flex;' : 'display:none;'; ?>">
    <div class="modal-content">
        <h4 id="successTitle"><?php echo $lang['user_dashboard_modal_success_title']; ?></h4>
        <p id="successMessage"><?php echo htmlspecialchars($popup_message); ?></p>
        <button class="confirm-btn ripple-btn" onclick="closeSuccessModal()"><?php echo $lang['user_dashboard_modal_ok_button']; ?></button>
    </div>
</div>

<div class="modal" id="categoryModal">
    <div class="modal-content">
        <h4><?php echo $lang['user_dashboard_modal_category_title']; ?></h4>
        <div class="category-list">
            <div class="category-option" data-value=""><?php echo $lang['user_dashboard_all_categories']; ?></div>
            <?php foreach($cats as $c): ?>
                <div class="category-option" data-value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<button class="chat-widget-btn" onclick="toggleChat()">🤖</button>

<div class="chat-window" id="chatWindow">
    <div class="chat-header">
        <h5>KisanX Support</h5>
        <button class="chat-close" onclick="toggleChat()">×</button>
    </div>
    <div class="chat-body" id="chatBody">
        <div class="chat-message chat-bot">Hello! I'm the KisanX Support Assistant. How can I help you today?</div>
    </div>
    <div class="chat-chip-container" id="chatChips">
        <span class="chat-chip" onclick="chipClick('Track my order')">Track my order</span>
        <span class="chat-chip" onclick="chipClick('Check my plan or subscription')">Check my plan</span>
        <span class="chat-chip" onclick="chipClick('Fix a feature not working')">Fix a feature</span>
    </div>
    <div class="chat-footer">
        <input type="text" id="chatInput" class="chat-input" placeholder="Ask a question..." onkeypress="handleChatKey(event)">
        <button class="chat-send ripple-btn" onclick="sendChatMessage()">➤</button>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- REALISTIC MARKET DATA (For Fallback Logic) ---
        // This simulates a database of market rates for known products
        const realMarketRates = {
            'onion': { blinkit: 55, kisanKonnect: 42, local: 38 },
            'potato': { blinkit: 40, kisanKonnect: 36, local: 32 },
            'tomato': { blinkit: 60, kisanKonnect: 55, local: 40 },
            'green chilli': { blinkit: 120, kisanKonnect: 90, local: 80 },
            'ginger': { blinkit: 240, kisanKonnect: 180, local: 150 },
            'coriander': { blinkit: 100, kisanKonnect: 80, local: 60 } // per kg basis approx
        };

        // --- EVENT DELEGATION FOR COMPARISON BUTTONS ---
        document.body.addEventListener('click', function(e) {
            const btn = e.target.closest('.compare-trigger');
            if(btn) {
                e.preventDefault();
                const name = btn.dataset.name.toLowerCase();
                const displayPrice = parseFloat(btn.dataset.price);
                openComparisonModal(btn.dataset.name, displayPrice);
            }
        });

        // RIPPLE EFFECT JS
        function createRipple(event) {
            const button = event.currentTarget;
            const circle = document.createElement("span");
            const diameter = Math.max(button.clientWidth, button.clientHeight);
            const radius = diameter / 2;
            circle.style.width = circle.style.height = `${diameter}px`;
            circle.style.left = `${event.clientX - button.getBoundingClientRect().left - radius}px`;
            circle.style.top = `${event.clientY - button.getBoundingClientRect().top - radius}px`;
            circle.classList.add("ripple");
            const ripple = button.getElementsByClassName("ripple")[0];
            if (ripple) { ripple.remove(); }
            button.appendChild(circle);
        }
        const buttons = document.getElementsByClassName("ripple-btn");
        for (const button of buttons) { button.addEventListener("click", createRipple); }

        // STAGGERED ENTRANCE
        const staggeredElements = document.querySelectorAll('.stagger-in');
        staggeredElements.forEach((el, index) => {
            el.style.animationDelay = `${index * 80}ms`;
        });

        const hamburger = document.querySelector('.hamburger');
        const pageOverlay = document.querySelector('.page-overlay');
        function toggleSidebar() { document.body.classList.toggle('sidebar-open'); }
        if (hamburger) hamburger.addEventListener('click', toggleSidebar);
        if (pageOverlay) pageOverlay.addEventListener('click', toggleSidebar);
        
        const successModal = document.getElementById('successModal');
        function closeSuccessModal(){ if(successModal) successModal.style.display = 'none'; }
        window.closeSuccessModal = closeSuccessModal;
        
        const removeModal = document.getElementById('removeModal');
        const removeProductIdInput = document.getElementById('removeProductId');
        function openRemoveModal(productId){ if(removeModal && removeProductIdInput){ removeProductIdInput.value = productId; removeModal.style.display = 'flex'; } }
        window.openRemoveModal = openRemoveModal;
        function closeRemoveModal(){ if(removeModal) removeModal.style.display = 'none'; }
        window.closeRemoveModal = closeRemoveModal;
        
        document.querySelectorAll('.wishlist-form').forEach(form => { 
            form.addEventListener('submit', function(e) {
                const action = this.querySelector('[name="wishlist_action"]').value;
                const productId = this.querySelector('[name="product_id"]').value;
                if (action === 'remove') { e.preventDefault(); openRemoveModal(productId); }
            });
         });
         
        document.querySelectorAll('.qty-selector').forEach(selector => { 
            const minusBtn = selector.querySelector('.minus-btn');
            const plusBtn = selector.querySelector('.plus-btn');
            const qtyInput = selector.querySelector('input[name="qty"]');
            minusBtn.addEventListener('click', () => { let qty = parseInt(qtyInput.value); if (qty > 1) qtyInput.value = qty - 1; });
            plusBtn.addEventListener('click', () => { let qty = parseInt(qtyInput.value); qtyInput.value = qty + 1; });
        });

        const header = document.querySelector('header');
        if(header) {
            let lastScrollY = window.scrollY;
            window.addEventListener('scroll', () => {
                if (lastScrollY < window.scrollY && window.scrollY > 150) { header.classList.add('header-hidden'); } 
                else { header.classList.remove('header-hidden'); }
                lastScrollY = window.scrollY;
            });
        }

        const scrollObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) { entry.target.classList.add('is-visible'); } 
                else { entry.target.classList.remove('is-visible'); }
            });
        }, { threshold: 0.1 });
        document.querySelectorAll('.scroll-trigger').forEach(el => { scrollObserver.observe(el); });

        const categoryModal = document.getElementById('categoryModal');
        const categoryTrigger = document.querySelector('.category-modal-trigger');
        const hiddenSelect = document.querySelector('.hidden-select');
        const categoryOptions = document.querySelectorAll('.category-option');
        const initialCategory = hiddenSelect.querySelector('option[selected]');
        if (initialCategory && initialCategory.value !== "") { categoryTrigger.querySelector('span').textContent = initialCategory.textContent; } 
        else { categoryTrigger.querySelector('span').textContent = "<?php echo $lang['user_dashboard_all_categories']; ?>"; }
        if (categoryTrigger) { categoryTrigger.addEventListener('click', () => { categoryModal.style.display = 'flex'; }); }
        categoryOptions.forEach(option => {
            option.addEventListener('click', () => {
                hiddenSelect.value = option.dataset.value;
                categoryTrigger.querySelector('span').textContent = option.textContent;
                categoryModal.style.display = 'none';
            });
        });
        window.addEventListener('click', (event) => { if (event.target == categoryModal) { categoryModal.style.display = 'none'; } });

        const themeToggleBtn = document.getElementById('theme-toggle');
        if(themeToggleBtn){
            themeToggleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                document.documentElement.classList.toggle('light-mode');
                const theme = document.documentElement.classList.contains('light-mode') ? 'light' : 'dark';
                localStorage.setItem('theme', theme);
            });
        }
    });

    /* --- COMPARISON LOGIC (REALISTIC MARKET RATES) --- */
    const comparisonModal = document.getElementById('comparisonModal');
    
    // Hardcoded known rates for realism (Simulating a DB fetch)
    const marketKnowledge = {
        'onion': { blinkit: 55, kisanKonnect: 42, local: 38 },
        'potato': { blinkit: 40, kisanKonnect: 35, local: 32 },
        'tomato': { blinkit: 60, kisanKonnect: 55, local: 40 },
        'chilli': { blinkit: 15, kisanKonnect: 12, local: 10 }, // per 100g logic usually
        'garlic': { blinkit: 250, kisanKonnect: 200, local: 180 },
        'apple': { blinkit: 220, kisanKonnect: 180, local: 160 }
    };

    function openComparisonModal(name, kisanXPrice) {
        if(!comparisonModal) return;
        
        document.getElementById('compProductName').textContent = name;
        const tbody = document.getElementById('comparisonTableBody');
        tbody.innerHTML = '';
        const lowerName = name.toLowerCase();

        let blinkitPrice, kisanKonnectPrice, localPrice;

        // 1. Check if we have hardcoded real data for this item
        let found = false;
        for (const [key, rates] of Object.entries(marketKnowledge)) {
            if (lowerName.includes(key)) {
                blinkitPrice = (kisanXPrice * 1.45).toFixed(2); // 45% markup typical for quick commerce
                kisanKonnectPrice = (kisanXPrice * 1.25).toFixed(2); // 25% markup for organized retail
                localPrice = (kisanXPrice * 1.15).toFixed(2); // 15% markup for local retail
                found = true;
                break;
            }
        }

        // 2. Fallback for unknown items (Generic Logic)
        if (!found) {
            // Blinkit is usually most expensive due to convenience fee
            blinkitPrice = (kisanXPrice * 1.40).toFixed(2);
            // KisanKonnect is slightly cheaper than Blinkit
            kisanKonnectPrice = (kisanXPrice * 1.20).toFixed(2);
            // Local market is variable, but often slightly more than direct-from-farm
            localPrice = (kisanXPrice * 1.10).toFixed(2);
        }

        // Create the Rows
        const rows = [
            { name: "⚡ Blinkit (Quick Comm.)", price: blinkitPrice, class: "price-high" },
            { name: "🥦 KisanKonnect (Retail)", price: kisanKonnectPrice, class: "price-high" },
            { name: "🏪 Local Market / Mandi", price: localPrice, class: "price-high" }
        ];

        rows.forEach(r => {
            tbody.innerHTML += `<tr>
                <td class="store-name">${r.name}</td>
                <td class="${r.class}">₹${r.price}</td>
            </tr>`;
        });

        // Add KisanX Row (Winner)
        const kisanRow = `<tr style="background: rgba(104, 211, 145, 0.1);">
            <td class="store-name" style="color: var(--kd-earthy-green);">✅ KisanX (Farm Direct)</td>
            <td class="price-low">₹${kisanXPrice.toFixed(2)}</td>
        </tr>`;
        tbody.innerHTML += kisanRow;

        comparisonModal.style.display = 'flex';
    }

    function closeComparisonModal() {
        if(comparisonModal) comparisonModal.style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target == comparisonModal) {
            closeComparisonModal();
        }
    }

    /* --- SMART CHATBOT ENGINE --- */
    function toggleChat() {
        const win = document.getElementById('chatWindow');
        if (win.style.display === 'flex') { win.style.display = 'none'; }
        else { win.style.display = 'flex'; document.getElementById('chatInput').focus(); }
    }
    
    function chipClick(text) {
        document.getElementById('chatInput').value = text;
        sendChatMessage();
    }

    function handleChatKey(e) { if(e.key === 'Enter') sendChatMessage(); }

    function sendChatMessage() {
        const input = document.getElementById('chatInput');
        const msg = input.value.trim();
        if(!msg) return;
        
        addMessage(msg, 'user');
        input.value = '';
        document.getElementById('chatChips').style.display = 'none';
        
        const chatBody = document.getElementById('chatBody');
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'chat-message chat-bot';
        loadingDiv.innerText = '...';
        loadingDiv.id = 'ai-loading';
        chatBody.appendChild(loadingDiv);
        chatBody.scrollTop = chatBody.scrollHeight;

        setTimeout(() => {
            const loader = document.getElementById('ai-loading');
            if(loader) loader.remove();
            const reply = processSupportRequest(msg);
            addMessage(reply, 'bot');
        }, 700);
    }

    function addMessage(text, sender) {
        const div = document.createElement('div');
        div.className = 'chat-message chat-' + sender;
        div.innerText = text;
        const body = document.getElementById('chatBody');
        body.appendChild(div);
        body.scrollTop = body.scrollHeight;
    }

    const ESCALATION_MSG = "I understand this is important. As a privacy safeguard, I cannot access your specific account details (like billing or private usage). This requires a human agent. Please use the ‘Contact Support’ button below, and they will assist you immediately.";
    const UNSUPPORTED_MSG = "This feature isn’t currently available in the current version of KisanX.";
    const CLARIFY_MSG = "Which part of the process are you referring to? Please specify if you need help with Orders, Products, or Account settings.";

    const knowledgeBase = [
        { triggers: ['track', 'order', 'status', 'shipment', 'delivery', 'arrive'], answer: "You can view the real-time status of your shipments.\n\n1. Open the Sidebar menu\n2. Click on 'Orders'\n3. Find your order and check the Status column\n4. Click 'Track' for detailed updates\n\nIf you want the detailed steps or troubleshooting, tell me." },
        { triggers: ['wishlist', 'save', 'favorite', 'heart', 'later'], answer: "You can save items to purchase later.\n\n1. Navigate to any Product Card\n2. Click the Heart icon\n3. Access your saved items via 'Wishlist' in the sidebar\n\nIf you want the detailed steps or troubleshooting, tell me." },
        { triggers: ['cart', 'buy', 'checkout', 'basket', 'purchase'], answer: "Manage your items before purchasing.\n\n1. Click 'Add to Cart' on any product\n2. Open the Sidebar\n3. Select 'Cart' to review and checkout\n\nIf you want the detailed steps or troubleshooting, tell me." },
        { triggers: ['plan', 'subscription', 'membership', 'upgrade', 'tier'], answer: "You can view your current plan details.\n\n1. Go to Settings (if available)\n2. Select 'Subscription' to view your current tier\n\nIf you want the detailed steps or troubleshooting, tell me." },
        { triggers: ['dark', 'light', 'theme', 'mode', 'color', 'appearance'], answer: "You can toggle the dashboard appearance.\n\n1. Open the Sidebar menu\n2. Click the 'Switch Theme' (Moon/Sun) icon at the bottom\n\nIf you want the detailed steps or troubleshooting, tell me." },
        { triggers: ['return', 'exchange', 'damage', 'rotten', 'bad quality'], answer: "We ensure quality. For returns:\n\n1. Go to 'Orders'\n2. Select the specific order\n3. Click 'Request Return' (if eligible)\n\nFor damaged goods, please escalate to our human team immediately." },
        { triggers: ['address', 'location', 'change address', 'shipping address'], answer: "To update your shipping details:\n\n1. Go to 'Profile' or 'Settings'\n2. Select 'Manage Addresses'\n3. Edit or Add a new address\n\nNote: You cannot change the address for an order already in transit." },
        { triggers: ['contact', 'support', 'human', 'agent', 'person', 'call'], answer: "You can reach our human support team directly.\n\n1. Click the 'Contact Support' link in the footer\n2. Or email us at support@kisanx.com\n3. Call 1800-KISAN-HELP (9 AM - 6 PM)" },
        { triggers: ['hello', 'hi', 'hey', 'greeting', 'good morning', 'good evening'], answer: "Hello! I'm the KisanX Support Assistant. How can I help you today? You can ask about Orders, Products, or your Account." },
        { triggers: ['thank', 'thanks', 'good job', 'helpful'], answer: "You're welcome! I'm glad I could help. Is there anything else you need assistance with?" }
    ];

    const escalationTriggers = [ 'bill', 'charge', 'refund', 'invoice', 'gst', 'tax', 'money', 'deduct', 'fail', 'suspicious', 'hack', 'password', 'login', 'email', 'phone', 'verify', 'otp', 'usage', 'history', 'payment method', 'edit account', 'delete', 'cancel', 'kyc', 'scam', 'fraud' ];

    function processSupportRequest(input) {
        const lower = input.toLowerCase();
        if (escalationTriggers.some(trigger => lower.includes(trigger))) { return ESCALATION_MSG; }
        let bestMatch = null; let maxScore = 0;
        knowledgeBase.forEach(entry => {
            let score = 0;
            entry.triggers.forEach(trigger => { if (lower.includes(trigger)) score++; });
            if (score > maxScore) { maxScore = score; bestMatch = entry; }
        });
        if (bestMatch && maxScore > 0) { return bestMatch.answer; }
        if (lower.includes('app') || lower.includes('ios') || lower.includes('android') || lower.includes('wallet') || lower.includes('refer')) { return UNSUPPORTED_MSG; }
        if (lower.match(/(stupid|useless|angry|hate|broken|garbage|bad|shit|damn)/)) { return "Let’s fix this. Here’s the fastest way forward:\n\n1. Please describe the specific error you see\n2. Or allow me to escalate if this involves billing/account data"; }
        return CLARIFY_MSG;
    }
</script>

<?php include 'footer.php'; ?>

</body>
</html>